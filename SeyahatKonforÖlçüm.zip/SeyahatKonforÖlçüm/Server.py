
from droneapi.lib import VehicleMode
from pymavlink import mavutil
import time
import numpy as np

from dronekit import connect, VehicleMode
import time
import argparse

import socket
import mysql.connector
from datetime import datetime
import time

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="1234",
    database="konforseyahat"
)








# Demo callback handler for raw MAVLink messages
def mavrx_debug_handler(message):
    print("Raw MAVLink message: ", message)





def server_program():
    # get the hostname
    # Connect to UDP endpoint.
    vehicle = connect('com11', wait_ready=True)
    decibleList=[45,50,55,60,65,70,75,80]
    decibleCounter=0
    f = open("C:/Users/Taylan/Desktop/SeyahatÖlçüm/demofile.txt", "r")
    for sentence in f:
        data = sentence.split(" ")  # split string into a list
        counter = 0
        temperature = 0
        location = 0
        decibel = 0
        coordX = 0
        coordY = 0
        coordZ = 0
        latitude = 0
        longitude = 0
        for temp in data:
            if counter == 0:
                temperature = float(temp)
            elif counter == 1:
                temp = temp.replace(' ', '')
                temp = temp.replace('\x00', '')
                temp = temp.replace('\n', '')
                #decibel = float(temp)
            counter=counter+1
        if decibleCounter==len(decibleList):
            decibleCounter=0
        decibel=decibleList[decibleCounter]
        decibleCounter=decibleCounter+1
        # Get all vehicle attributes (state)

        coordX=round(float(vehicle.attitude.roll),2)
        coordY=round(float(vehicle.attitude.pitch),2)
        coordZ=round(float(vehicle.attitude.yaw),2)
        locationString=str(vehicle.location.global_frame)
        split_string = locationString.split(",")
        lat = split_string[0].split("=")
        lon = split_string[1].split("=")
        insertDatabase(temperature, decibel, coordX, coordY, coordZ, lat[1], lon[1])
        time.sleep(5)


def insertDatabase(temperature, decibel, coordX, coordY, coordZ, latitude, longitude):
    mycursor = mydb.cursor()
    nocursır = mydb.cursor()
    i = 0
    nocursır.execute("SELECT * FROM measures")
    for row in nocursır:
        i = i + 1
    grade = 1
    if decibel < 50:
        grade = grade + 3
    elif decibel >= 50 and decibel <= 60:
        grade = grade + 2.4
    elif decibel >= 60 and decibel <= 70:
        grade = grade + 1.8
    elif decibel >= 70 and decibel <= 80:
        grade = grade + 1.2
    else:
        grade = grade + 0.6

    if temperature < 16:
        grade = grade + 0
    elif temperature >= 16 and temperature <= 18:
        grade = grade + 1
    elif temperature >= 18 and temperature <= 20:
        grade = grade + 2
    elif temperature >= 20 and temperature <= 22:
        grade = grade + 3
    elif temperature >= 22 and temperature <= 24:
        grade = grade + 3
    elif temperature >= 24 and temperature <= 26:
        grade = grade + 2
    elif temperature >= 26 and temperature <= 28:
        grade = grade + 1
    else:
        grade = grade + 0


    if coordY>=-0.25 and coordY<=0.25:
        grade = grade + 1.5
    elif (coordY >= -0.5 and coordY<=-0.25) or (coordY <= 0.5 and coordY>=0.25):
        grade = grade + 1
    elif (coordY >= -0.75 and coordY<=-0.5) or (coordY <= 0.75 and coordY>=0.5):
        grade = grade + 0.5
    else:
        grade = grade

    if coordZ>=-0.5 and coordZ<=0.5:
        grade = grade + 1.5
    elif (coordZ >= -1 and coordZ<=-0.5) or (coordZ <= 1 and coordZ>=0.5):
        grade = grade + 1
    elif (coordZ >= -1.5 and coordZ<=-1) or (coordZ <= 1.5 and coordZ>=1):
        grade = grade + 0.5
    else:
        grade = grade



    timeHMS = datetime.now().strftime('%H:%M:%S')
    timeDate = datetime.now().strftime('%Y%m%d')
    number = str(i)
    print(number,temperature,decibel,coordX,coordY,coordZ,grade, latitude, longitude,timeDate, timeHMS)
    sql = (
    "INSERT INTO measures" "(no, temperature,decibel,koordX,koordY,koordZ,date,time,grade,latitude,longitude)" "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s )")

    val = (number, temperature, decibel, coordX, coordY, coordZ, timeDate, timeHMS, grade, latitude, longitude)
    print("time", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    mycursor.execute(sql, val)
    mydb.commit()
    print(mycursor.rowcount, "was inserted temp.")


if __name__ == '__main__':
    server_program()