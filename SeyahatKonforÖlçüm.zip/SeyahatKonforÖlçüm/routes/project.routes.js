const fs = require('fs');
const express = require("express");

const router = express.Router();

const projectController = require('../controllers/project.controller')

router.get('/', projectController.getProjectPage);
router.get('/add', projectController.addProjectPage);
router.post('/add', projectController.addProject);

module.exports = router;
