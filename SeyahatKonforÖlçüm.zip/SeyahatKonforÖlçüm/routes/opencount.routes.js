const fs = require('fs');


var express    = require('express')
var bodyParser = require('body-parser')
var app = express()
var cors=require('cors');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))

// parse application/json
app.use(bodyParser.json())

// parse application/vnd.api+json as json
app.use(bodyParser.json({ type: 'application/vnd.api+json' }))
app.use(cors());
app.use('/sorgu',function (req, res, next) {
    console.log(req.body) // populated!
});


const router = express.Router();

router.use(cors());
var bodyParser = require("body-parser");
router.use(bodyParser.urlencoded({ extended: true }))
router.use(bodyParser.json());
router.use(bodyParser.json({ type: 'application/vnd.api+json' }))

const opencountController = require('../controllers/opencount.controller')
app.post('*', function (req, res, next) {
    console.log("url = ", req.url, "  req-body  = ", req.body,   "res-type  = ", res.get('Content-Type'));
    res.sendFile(indexPath);
  })

 app.post('/sorgu', function(req, res, next) {
    
    var platform = req.body.startDate;
    console.log("url = ", req.url, "  req-body  = ", req.body,   "res-type  = ", res.get('Content-Type'));

})
router.get('/', opencountController.getOpenCountPage);
router.get('/sorgu', opencountController.sorgulaComment);
router.post('/sorgu', opencountController.sorgulaComment);

module.exports = router;



