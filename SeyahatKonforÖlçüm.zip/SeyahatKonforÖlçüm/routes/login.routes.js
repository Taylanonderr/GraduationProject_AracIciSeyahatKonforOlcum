const express = require("express");

const router = express.Router();

const loginController = require('../controllers/home.controller');

router.get('/', loginController.getHomePage);
router.post('/', loginController.getHomePage);

module.exports = router;
