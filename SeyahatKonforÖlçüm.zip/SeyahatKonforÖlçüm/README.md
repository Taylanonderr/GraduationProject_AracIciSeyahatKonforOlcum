Merhabalar,

Arayüz, sensör verilerinin alınması ve veritabanına yazılması dahil tüm kodlar bu zipin 
içerisindedir.Ardunio klasörünün içerisinde sıcaklık sensör değer okunması ve 
Server.py dosyasında da diğer sensör bilgilerinin alınıp arduniodan gelen sıcaklık bilgisi
ile veri tabanına yazılması kodlanmıştır.Arayüz node app.js komutu ile terminalden 
çalıştırılarak http://localhost:9058/ ile erişilebilir.Veritabanı localhosttan çalıştığı
için denerken hata verebilir.Önceki sunumlarda kullandığım powerpointlerde zip içerisindedir.

Teşekkürler.