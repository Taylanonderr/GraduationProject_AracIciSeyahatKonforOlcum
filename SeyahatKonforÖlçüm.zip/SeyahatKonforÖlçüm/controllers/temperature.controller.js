const fs = require('fs');


exports.getTemperaturePage = (req, res) => {
    res.render('temperature.ejs', {
        title: "temperature",
        temperatures: 0,
        success: ""
    });

};

exports.sorgulaCommentTemperature = (req, res) => {
    for (var bodyKey in req.body) {
        console.log("params : ",bodyKey);

    }

    let message = '';
    let start = req.body.startDate;
    console.log("url : ",req);
    let end = req.body.endDate;
    let description = req.body.description;
    console.log("description : ",description);
    console.log("start : ",start);
    var parseStartDate = start.split("-");
     start="";
    for(i = 0; i < parseStartDate.length; i++)
        start+=parseStartDate[i];
    var parseEndDate = end.split("-");
     end="";
    for(i = 0; i < parseEndDate.length; i++)
        end+=parseEndDate[i]; 

    let query = "SELECT * FROM measures "+"where date> "+start +" and date< "+end +" ORDER BY no ASC";
    console.log(query);

    // execute query
    db.query(query, (err, result) => {
        console.log(result);
        if (err) {
            res.redirect('/temperature');
            console.log(err);
        }
        else if(result.length==0){
            console.error("Girilen tarih aralığı için kayıt bulunamamıştır.");
            res.render('temperature.ejs', {
                title: "temperature",
                temperatures: "",
                success: "error"
            });
        }
        else{
            res.render('temperature.ejs', {
                title: "temperature",
                temperatures: result,
                success: ""
            });
        }
    });
};


