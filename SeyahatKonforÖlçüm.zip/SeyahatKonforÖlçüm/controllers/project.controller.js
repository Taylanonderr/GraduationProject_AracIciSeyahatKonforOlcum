const fs = require('fs');


exports.getProjectPage = (req, res) => {

    // execute query

    res.render('project.ejs', {
        title: "Project",
    });

};

exports.addProjectPage = (req, res) => {
    res.render('add-project.ejs', {
        title: "Add Project",
        message: ''
    });
};



exports.addProject = (req, res) => {{
    
    let message = '';
    let project_name = req.body.project_name;
    let description = req.body.description;

    let projectQuery = "SELECT * FROM `project` WHERE project_name = '" + project_name + "'";

    db.query(projectQuery, (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).send(err);
        }

        if (result.length > 0) {
            message = 'Project already exists';
            res.render('add-project.ejs', {
                message,
                title: "Add Project"
            });
        } else {
            
            let query = "INSERT INTO `project` (project_name, description) VALUES ('" +
            project_name + "', '" + description + "')";
            db.query(query, (err, result) => {
                if (err) {
                    return res.status(500).send(err);
                }
                res.redirect('/project');
            });

        }
    });
}};