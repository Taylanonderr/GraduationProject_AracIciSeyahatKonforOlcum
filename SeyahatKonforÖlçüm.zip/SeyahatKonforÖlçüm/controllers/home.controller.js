const fs = require('fs');

exports.getHomePage = (req, res) => {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();
    
    var dateToday = parseInt(yyyy+mm+dd) ;
    console.log(dateToday);
    let query1 = "SELECT temperature FROM measures where date= "+dateToday +" ORDER BY no ASC";
    let query2 = "SELECT temperature FROM measures where date= "+dateToday +" ORDER BY no ASC";
    let query3 = "SELECT count(no) FROM measures where date= "+dateToday +" ORDER BY no ASC";
    var data1,data2,data3;
    var lat=40.824770054152054;
    var lon=29.320925171411417;
    // execute query

    let queryTemp = "SELECT * FROM measures ORDER BY no DESC LIMIT 1;";
    data1=db.query(queryTemp, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        data1=result;
        return data1;
    });
    var hh = String(today.getHours()-1).padStart(2, '0');
    var minute = String(today.getMinutes()).padStart(2, '0');
    var second = String(today.getSeconds()).padStart(2, '0');

    var timeToday = parseInt(hh+minute+second) ;
    console.log(timeToday);
    let queryopenhour = "SELECT * FROM measures where date= "+dateToday +" AND closetime> "+timeToday + "ORDER BY no ASC";
    data2=db.query(queryopenhour, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        data2=result;
        return data2;
    });
    let queryopenday = "SELECT * FROM measures where date= "+dateToday +" ORDER BY no ASC";
    data3=db.query(queryopenday, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        data3=result;
        return data3;
    });
    var last = new Date(today.getTime() - (7 * 24 * 60 * 60 * 1000));
    var day =String(last.getDate()).padStart(2, '0');
    var month=String(last.getMonth()+1).padStart(2, '0');
    var year=String(last.getFullYear()).padStart(2, '0');
    var timeWeek = parseInt(year+month+day) ;
    console.log("week : "+timeWeek);
    let queryopenweek = "SELECT * FROM measures where date<= "+dateToday +" AND date>= "+timeWeek +" ORDER BY no ASC";
    console.log("queryopenweek : "+queryopenweek);
    var data4=db.query(queryopenweek, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        data4=result;
        return data4;
    });

    var lastmonth = new Date(today.getTime() - (30 * 24 * 60 * 60 * 1000));
    var daymonth =String(lastmonth.getDate()).padStart(2, '0');
    var monthmonth=String(lastmonth.getMonth()+1).padStart(2, '0');
    var yearmonth=String(lastmonth.getFullYear()).padStart(2, '0');
    var timemonth = parseInt(yearmonth+monthmonth+daymonth) ;
    let queryopenmonth = "SELECT * FROM measures where date<= "+dateToday +" AND date>= "+timemonth +" ORDER BY no ASC";
    var data5=db.query(queryopenmonth, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        data5=result;
        return data5;
    });


    let querytempavgday = "SELECT AVG(temperature) FROM measures where date= "+dateToday +" ORDER BY no ASC";
    var datatempavgday=db.query(querytempavgday, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log("avg :"+result)
        datatempavgday=result;
        return datatempavgday;
    });

    let querytempavgweek = "SELECT AVG(temperature) FROM measures where date<= "+dateToday +" AND date>= "+timeWeek +" ORDER BY no ASC";
    var datatempavgweek=db.query(querytempavgweek, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        datatempavgweek=result;
        return datatempavgweek;
    });

    let querytempavgmonth = "SELECT AVG(temperature) FROM measures where date<= "+dateToday +" AND date>= "+timemonth +" ORDER BY no ASC";
    var datatempavgmonth=db.query(querytempavgmonth, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        datatempavgmonth=result;
        return datatempavgmonth;
    });











    let querygradeavgday = "SELECT AVG(grade) FROM measures where date= "+dateToday +" ORDER BY no ASC";
    var datagradeavgday=db.query(querygradeavgday, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log("avg :"+result)
        datagradeavgday=result;
        return datagradeavgday;
    });

    let querygradeavgweek = "SELECT AVG(grade) FROM measures where date<= "+dateToday +" AND date>= "+timeWeek +" ORDER BY no ASC";
    var datagradeavgweek=db.query(querygradeavgweek, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        datagradeavgweek=result;
        return datagradeavgweek;
    });

    let querygradeavgmonth = "SELECT AVG(grade) FROM measures where date<= "+dateToday +" AND date>= "+timemonth +" ORDER BY no ASC";
    var datatempavgmonth=db.query(querygradeavgmonth, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        datatempavgmonth=result;
        return datatempavgmonth;
    });








    let queryHumavgday = "SELECT AVG(decibel) FROM measures where date= "+dateToday +" ORDER BY no ASC";
    var dataHumavgday=db.query(queryHumavgday, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        dataHumavgday=result;
        return dataHumavgday;
    });

    let queryHumavgweek = "SELECT AVG(decibel) FROM measures where date<= "+dateToday +" AND date>= "+timeWeek +" ORDER BY no ASC";
    var dataHumavgweek=db.query(queryHumavgweek, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        dataHumavgweek=result;
        return dataHumavgweek;
    });

    let queryHumavgmonth = "SELECT AVG(decibel) FROM measures where date<= "+dateToday +" AND date>= "+timemonth +" ORDER BY no ASC";
    var dataHumavgmonth=db.query(queryHumavgmonth, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        dataHumavgmonth=result;
        res.render('home.ejs', {
            title: "home",
            data1: data1,
            data2: data2,
            data3: data3,
            data4: data4,
            data5: data5,
            datatempavgday:datatempavgday,
            datatempavgweek:datatempavgweek,
            datatempavgmonth:datatempavgmonth,
            datagradeavgday:datagradeavgday,
            datagradeavgweek:datagradeavgweek,
            dataHumavgday:dataHumavgday,
            dataHumavgweek:dataHumavgweek,
            dataHumavgmonth:result,
            lat: lat,
            lon: lon,
        });
        return dataHumavgmonth;
    });

};

function getData(){
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();
    
    var dateToday = parseInt(yyyy+mm+dd) ;
    console.log(dateToday);
    let query1 = "SELECT temperature FROM measures where date= "+dateToday +" ORDER BY no ASC";
    let query2 = "SELECT decibel FROM measures where date= "+dateToday +" ORDER BY no ASC";
    var data1,data2,data3; 
    // execute query
    data1=db.query(query1, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result);
        return result;
    });
    console.log("Dışarısı "+ data1.result);

    data2=db.query(query2, (err, data2) => {
        if (err) {
            //res.redirect('/home');
        }
        return data2.fields;
    });

    data3=db.query(query3, (err, data3) => {
        if (err) {
            //
        }
        console.log(data3);
        return data3.fields;
    });

    console.log(data1.fields);
    console.log(data2.fields);
    console.log(data3.fields);
    let queryTemp = "SELECT * FROM measures ORDER BY no DESC LIMIT 1;";
    data1=db.query(queryTemp, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        res.render('home.ejs', {
            title: "home",
            data1: result,
            data2: 0,
        });
    });
    let queryopen = "SELECT count(no) FROM measures where date= "+dateToday +" ORDER BY no ASC";
    data2=db.query(queryopen, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        res.render('home.ejs', {
            title: "home",
            data1: data1,
            data2: result,
        });
    });


}

