const fs = require('fs');

exports.getHomePage = (req, res) => {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();
    
    var dateToday = parseInt(yyyy+mm+dd) ;
    console.log(dateToday);
    let query1 = "SELECT temperature FROM temperaturehumuditytable where date= "+dateToday +" ORDER BY no ASC"; 
    let query2 = "SELECT temperature FROM temperaturehumuditytable where date= "+dateToday +" ORDER BY no ASC"; 
    let query3 = "SELECT count(no) FROM openingamountofdoor where date= "+dateToday +" ORDER BY no ASC"; 
    var data1,data2,data3; 
    // execute query

    let queryTemp = "SELECT * FROM measures ORDER BY no DESC LIMIT 1;";
    data1=db.query(queryTemp, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        data1=result;
        return data1;
    });
    let queryopenday = "SELECT * FROM measures where date= "+dateToday +" ORDER BY no ASC";
    data2=db.query(queryopenday, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        data2=result;
        return data2;
    });
    let queryopenweek = "SELECT * FROM openingamountofdoor where date= "+dateToday +" ORDER BY no ASC"; 
    data3=db.query(queryopenweek, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        data3=result;
        return data3;
    });
    let queryopenmonth = "SELECT * FROM openingamountofdoor where date<= "+dateToday +" ORDER BY no ASC"; 
    var data4=db.query(queryopenmonth, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        res.render('home.ejs', {
            title: "home",
            data1: data1,
            data2: data2,
            data3: data3,
            data4: result,

        });
    });

};

function getData(){
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();
    
    var dateToday = parseInt(yyyy+mm+dd) ;
    console.log(dateToday);
    let query1 = "SELECT temperature FROM temperaturehumuditytable where date= "+dateToday +" ORDER BY no ASC"; 
    let query2 = "SELECT humudity FROM temperaturehumuditytable where date= "+dateToday +" ORDER BY no ASC"; 
    var data1,data2,data3; 
    // execute query
    data1=db.query(query1, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result);
        return result;
    });
    console.log("Dışarısı "+ data1.result);

    data2=db.query(query2, (err, data2) => {
        if (err) {
            //res.redirect('/home');
        }
        return data2.fields;
    });

    data3=db.query(query3, (err, data3) => {
        if (err) {
            //
        }
        console.log(data3);
        return data3.fields;
    });

    console.log(data1.fields);
    console.log(data2.fields);
    console.log(data3.fields);
    let queryTemp = "SELECT * FROM temperaturehumuditytable ORDER BY no DESC LIMIT 1;"; 
    data1=db.query(queryTemp, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        res.render('home.ejs', {
            title: "home",
            data1: result,
            data2: 0,
        });
    });
    let queryopen = "SELECT count(no) FROM openingamountofdoor where date= "+dateToday +" ORDER BY no ASC"; 
    data2=db.query(queryopen, (err, result) => {
        if (err) {
            //res.redirect('/home');
        }
        console.log(result)
        res.render('home.ejs', {
            title: "home",
            data1: data1,
            data2: result,
        });
    });


}

