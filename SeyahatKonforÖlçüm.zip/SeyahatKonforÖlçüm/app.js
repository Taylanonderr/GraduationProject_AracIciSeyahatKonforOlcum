const express = require('express');
const fileUpload = require('express-fileupload');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

const loginRoutes = require('./routes/login.routes');
const homeRoutes = require('./routes/home.routes');
const projectRoutes = require('./routes/project.routes');
const temperatureRoutes = require('./routes/temperature.routes');
const opencountRoutes = require('./routes/opencount.routes')
const port = 9058;
var mysql = require('mysql');
var session = require('express-session');
app.use(express.static('public'));
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}))

// create connection to database
// the mysql.createConnection function takes in a configuration object which contains host, user, password and the database name.
const db = mysql.createConnection ({
    host: 'localhost',
    user: 'root',
    password: '1234',
    database: 'konforseyahat'
});

// connect to database
db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Connected to database');
});
global.db = db;

// configure middleware
app.set('port', process.env.port || port); // set express to use this port
console.log('1');
app.set('views', __dirname + '/views'); // set express to look in this folder to render our view
app.set('view engine', 'ejs'); // configure template engine
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()); // parse form data client
app.use(express.static(path.join(__dirname, 'public'))); // configure express to use public folder
app.use(fileUpload()); // configure fileupload
console.log('1234');

app.use('/home', homeRoutes);
app.use('/', loginRoutes);
app.use('/temperature', temperatureRoutes);
app.use('/opencount', opencountRoutes);
app.use('/project', projectRoutes);


app.get('*', function(req, res, next){
    res.status(404);

    res.render('404.ejs', {
        title: "Page Not Found",
    });

});

// set the app to listen on the port
app.listen(port, () => {
    console.log(`Server running on port: ${port}`);
});